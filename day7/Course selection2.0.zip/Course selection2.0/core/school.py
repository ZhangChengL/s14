#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:Zhangcl
class School(object):
    def __init__(self,school_name,school_address):
        self.school_name=school_name
        self.school_address=school_address
